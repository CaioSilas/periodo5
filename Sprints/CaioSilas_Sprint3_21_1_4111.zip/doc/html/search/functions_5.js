var searchData=
[
  ['logistic_0',['Logistic',['../class_logistic.html#aeb4d2b17923cab070f950aef14953cb3',1,'Logistic']]],
  ['logisticalfuncionaltest_1',['logisticalFuncionalTest',['../funcional__testes_8cpp.html#a60914db64bde71b56d69320797266c29',1,'logisticalFuncionalTest():&#160;funcional_testes.cpp'],['../funcional__testes_8h.html#a60914db64bde71b56d69320797266c29',1,'logisticalFuncionalTest():&#160;funcional_testes.cpp']]]
];
