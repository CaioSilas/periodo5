var searchData=
[
  ['debuging_0',['DEBUGING',['../main_8cpp.html#aeff79046387df0de04e7de11061a704b',1,'main.cpp']]]
];
