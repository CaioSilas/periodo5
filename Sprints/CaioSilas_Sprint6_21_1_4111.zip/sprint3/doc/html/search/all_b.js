var searchData=
[
  ['operator_3d_0',['operator=',['../class_handle.html#a52e146e2a1427c8e7d3a692e9378185a',1,'Handle']]]
];
