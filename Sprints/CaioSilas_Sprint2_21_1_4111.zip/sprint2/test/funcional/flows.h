#ifndef FLOWS_H
#define FLOWS_H

#include "../../src/Flow.h"
#include <iostream>
#include <string>
#include <cassert>
#include <cstdlib>

class Exponential : public Flow{
    public:
        Exponential(const string name = "", System* source = NULL, System* destiny = NULL) : Flow(name, source, destiny) {}

        virtual double execute(void){
            return 0.01 * source->getValue();
        }
};

class Logistic : public Flow{
    public:
        Logistic(const string name = "", System* source = NULL, System* destiny = NULL) : Flow(name, source, destiny) {}

        virtual double execute(void){
            return 0.01 * (destiny->getValue())*(1-(destiny->getValue())/70);
        }
};

class MyFlow : public Flow{
    public:
        MyFlow(const string name = "", System* source = NULL, System* destiny = NULL) : Flow(name, source, destiny) {}

        virtual double execute(void){
            return 0.01 * source->getValue();
        }
};



#endif