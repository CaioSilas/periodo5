#ifndef FUNCIONAL_TESTES_H
#define FUNCIONAL_TESTES_H

void exponentialFuncionalTest();
void logisticalFuncionalTest();
void complexFuncionalTest();

#endif