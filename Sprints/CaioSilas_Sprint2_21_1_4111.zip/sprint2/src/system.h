#ifndef SYSTEM_H
#define SYSTEM_H

#include <string>

using namespace std;

class System {
    public:
        System();
        System(string = "", double = 0);
        virtual ~System();

        //sets
        void setName(const string);
        void setValue(const double);

        //gets
        string getName() const;
        double getValue() const;

    protected:
        string name;
        double value;
    private:
         

        System(const System& obj); 
        System& operator=(const System& rhs); 
};

#endif