#ifndef MODEL_H
#define MODEL_H

#include <string>
#include <vector>
#include <iterator>
#include "flow.h"
#include "system.h"

using namespace std;

class Model {
    public:
        Model();
        Model(string = "", double = 0);
        virtual ~Model();

        void add(System*);
        void add(Flow*);
        void run(int = 0, int = 0, int = 1);

        typedef vector<System*>::iterator systemIterator;
        typedef vector<Flow*>::iterator flowIterator;

        systemIterator systemBegin(void);
        systemIterator systemEnd(void);
        flowIterator flowBegin(void);
        flowIterator flowEnd(void);

        //sets
        void setName(const string);
        void setTime(const double);

        //gets
        string getName() const;
        double getTime() const;

    protected:
        string name;
        double time;
        vector<System*> systems;
        vector<Flow*> flows;

    private:
        Model(const Model& obj);  
        Model& operator=(const Model&); 
};

#endif