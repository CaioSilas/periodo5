#ifndef FLOW_H
#define FLOW_H

#include <string>
#include "system.h"

using namespace std;

class Flow {
    public:
        Flow();
        Flow(string = "", System* = NULL, System* = NULL);
        virtual ~Flow();

        void connect(System* = NULL, System* = NULL);
        virtual double execute() = 0;

        //sets
        void setName(const string);
        void setValue(const double);
        void setSource(System*);
        void setDestiny(System*);

        //gets
        string getName() const;
        double getValue() const;
        System* getSource() const;
        System* getDestiny() const;


    protected:
        string name;
        double value;
        System* source;
        System* destiny;

    private:

        Flow(const Flow& obj);  
        Flow& operator=(const Flow& rhs); 
};

#endif

