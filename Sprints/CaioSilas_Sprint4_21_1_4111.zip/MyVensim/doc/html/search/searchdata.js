var indexSectionsWithContent =
{
  0: "acdefgmnrsv~",
  1: "fms",
  2: "fms",
  3: "acefgmrs~",
  4: "dnsv",
  5: "fs"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs"
};

